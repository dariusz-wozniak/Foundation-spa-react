// wrapped by build app
define("content-graph/package", ["dojo","dijit","dojox"], function(dojo,dijit,dojox){
// eslint-disable-next-line no-unused-vars
var profile = {
    // Resource tags are functions that provide hints to the build system about the way files should be processed.
    // Each of these functions is called once for every file in the package directory. The first argument passed to
    // the function is the filename of the file, and the second argument is the computed AMD module ID of the file.
    resourceTags: {
        // Files that contain test code and should be excluded when the `copyTests` build flag exists and is `false`.
        test: function (filename, mid) {
            return false;
        },

        // Files that should be copied as-is without being modified by the build system.
        copyOnly: function (filename, mid) {
            return /.css/.test(filename) || /\/Images\//.test(filename) || /\/Setting\//.test(filename);
        },

        // Files that are AMD modules.
        amd: function (filename, mid) {
            return !this.copyOnly(filename, mid) && /\.js$/.test(filename) && !/\jquery-3.5.1.min.js$/.test(filename);
        },

        // Files that should not be copied when the `mini` build flag is set to true.
        // In this case, we are excluding this package configuration file which is not necessary in a built copy of
        // the application.
        miniExclude: function (filename, mid) {
            return mid in {
                "content-graph/package": 1,
                "content-graph/package.json": 1
            };
        },

        // Ignore node_modules and react stuff
        ignore: function (filename, mid) {
            return /\/Setting\//.test(filename) && !/\/Setting\/dist\//.test(filename);
        }
    }
};

});
