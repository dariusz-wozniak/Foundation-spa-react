define("content-graph/ContentGraphCommandProvider", [
  "dojo",
  "dojo/_base/declare",
  "epi/shell/command/_CommandProviderMixin",
  "content-graph/SynchronizeCommand"
],
  function (dojo, declare, _CommandProviderMixin, SynchronizeCommand) {
    return declare([_CommandProviderMixin],
    {
      // summary:
      //      Provides synchronize command to the Publish menu.
      // tags:
      //      internal

      constructor: function (command) {
        this.inherited(arguments);
        this.add("commands", command);
      }
    });
  }
);
