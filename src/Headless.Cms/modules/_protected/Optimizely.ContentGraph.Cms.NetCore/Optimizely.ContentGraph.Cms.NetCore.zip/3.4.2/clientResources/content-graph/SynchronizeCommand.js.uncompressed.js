define("content-graph/SynchronizeCommand", [
  "dojo/_base/declare",
  "dojo/when",
  "dojo/_base/lang",

  "epi/shell/command/_Command",
  "epi/dependency",
  "epi-cms/_ContentContextMixin",
  // resources
  "epi/i18n!epi/cms/nls/optimizely.contentgraph.editview"
],
  function (declare, when, lang, _Command, dependency, _ContentContextMixin, resources) {
    return declare([_Command, _ContentContextMixin],
    {
      // tags:
      //      public

      name: "Synchronize",
      label: resources.synchronize,
      iconClass: "epi-iconRight",
      canExecute: true,
      order: 10000,

      constructor: function () {
        var registry = dependency.resolve("epi.storeregistry");
        this.store = this.store || registry.get("epi-contentgraph.contentindexing");
      },

      _execute: function () {
        // summary:
        //      Trigger when user click on the menu item.
        // tags:
        //      protected

        when(this.getCurrentContext(), lang.hitch(this, function (context) {
          this.store.executeMethod("SynchronizeContent", null, context.id);
        }));
      },

      _onModelChange: function () {
        this.updateSyncStatus()
      },

      updateSyncStatus: function () {
        when(this.getCurrentContext(), lang.hitch(this, function (context) {
          when(this.store.executeMethod("getSyncStatus", null, context.id), lang.hitch(this, function (res) {
             this.set('iconClass', res ? "epi-iconRight" : "epi-iconUpload");
            })
          )
        }));
      }
    });
  }
);
