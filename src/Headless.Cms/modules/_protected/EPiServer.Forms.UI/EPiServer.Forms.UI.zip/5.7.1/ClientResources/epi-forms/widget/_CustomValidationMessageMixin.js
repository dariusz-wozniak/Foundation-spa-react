define("epi-forms/widget/_CustomValidationMessageMixin", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "epi"], function ( // dojo
declare, lang, epi) {
  // module:
  //      epi-forms/widget/_CustomValidationMessageMixin
  // summary:
  //
  // tags:
  //      internal
  return declare(null, {
    // formEditingViewModel: [public] Object
    //
    formEditingViewModel: null,
    // defaultValidatorMessage: [public] String
    //
    defaultValidatorMessage: null,
    _updateModelValidatorMessagesProperty: function _updateModelValidatorMessagesProperty(
    /*String*/
    validatorType,
    /*String*/
    validatorMessage) {
      var _this$formEditingView;

      // summary:
      //      Insert/Update message for a validator
      // tags:
      //      protected
      var oldValidatorMessages = (_this$formEditingView = this.formEditingViewModel) === null || _this$formEditingView === void 0 ? void 0 : _this$formEditingView.getProperty("validatorMessages"),
          newValidatorMessages = oldValidatorMessages ? lang.clone(oldValidatorMessages) : [],
          updated = false;

      for (var i = 0; i < newValidatorMessages.length; i++) {
        if (newValidatorMessages[i].validator === validatorType) {
          newValidatorMessages[i].message = validatorMessage;
          updated = true;
          break;
        }
      }

      if (!updated) {
        newValidatorMessages.push({
          validator: validatorType,
          message: validatorMessage
        });
      }

      var model = this.formEditingViewModel;

      if (!epi.areEqual(newValidatorMessages, oldValidatorMessages)) {
        model.raiseCustomValidationMessageChangeEvent = false;
        model.setProperty("validatorMessages", newValidatorMessages, oldValidatorMessages);
        model.raiseCustomValidationMessageChangeEvent = true;
      }
    }
  });
});