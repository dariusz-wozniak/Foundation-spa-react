define("epi-forms/widget/command/CreateContentFromSelector", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/topic", "dojo/when", // epi
"epi/shell/widget/dialog/Alert", "epi/shell/TypeDescriptorManager", "epi-cms/widget/command/CreateContentFromSelector", "epi-cms/widget/ContentTypeList", // epi-addons
"epi-forms/ModuleSettings", // res
"epi/i18n!epi/cms/nls/contenttypes.blockbase"], function ( // dojo
declare, lang, topic, when, // epi
Alert, TypeDescriptorManager, CreateContentFromSelector, ContentTypeList, // epi-addons
ModuleSettings, // res
createBlockRes) {
  // module:
  //      epi-forms/widget/command/CreateContentFromSelector
  // summary:
  //
  // tags:
  //      public
  return declare([CreateContentFromSelector], {
    constructor: function constructor() {
      // Use settings to display root folder of EPiServer Forms on SelectContentDialog
      this.set("roots", ModuleSettings.roots);
    },
    _switchView: function _switchView(
    /*Object*/
    content) {
      // summary:
      //      Change view to Create Content with parent content
      // content: [Object]
      //
      // tags:
      //      protected, extensions
      if (!this.isInQuickEditMode && !this.keepCurrentView) {
        when(this.getCurrentContent(), lang.hitch(this, function (contextContent) {
          topic.publish("/epi/shell/action/changeview", "epi-forms/contentediting/CreateContent", null, {
            contentTypeId: this.contentTypeId,
            requestedType: this.creatingTypeIdentifier,
            parent: contextContent,
            showAllProperties: false,
            addToDestination: this.model,
            createAsLocalAsset: true,
            treatAsSecondaryView: true,
            view: TypeDescriptorManager.getValue(this.creatingTypeIdentifier, "createView"),
            autoPublish: true,
            allowedTypes: this.allowedTypes,
            restrictedTypes: this.restrictedTypes
          });
        }));
      } else {
        var _this = this;

        var dialog;
        var contentTypeList = new ContentTypeList({
          allowedTypes: this.allowedTypes,
          restrictedTypes: this.restrictedTypes,
          localAsset: true,
          parentLink: content.contentLink,
          onContentTypeSelected: function onContentTypeSelected(selectedType) {
            if (dialog) {
              dialog.hide();
            }

            _this._createInlineEditDialog(content, selectedType);
          }
        });

        _this.own(contentTypeList.watch("shouldSkipContentTypeSelection", function () {
          if (contentTypeList.get("shouldSkipContentTypeSelection")) {
            return;
          }

          dialog = new Alert({
            // eslint-disable-next-line no-undef
            acknowledgeActionText: epi.resources.action.close,
            closeIconVisible: false,
            content: contentTypeList,
            dialogClass: "epi-dialog-portrait inline-edit-dialog",
            title: createBlockRes.create
          });
          dialog.show();
          dialog.containerNode.classList.add("create-content-dialog");

          _this.own(dialog);

          contentTypeList._suggestedContentTypes.setVisibility(false);
        }));

        contentTypeList.set("requestedType", ModuleSettings.formElementBaseContentType);
        contentTypeList.refresh();

        _this.own(contentTypeList);
      }
    }
  });
});