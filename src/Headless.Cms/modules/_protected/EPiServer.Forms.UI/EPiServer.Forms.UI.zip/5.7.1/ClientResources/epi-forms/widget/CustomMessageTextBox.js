require({
  cache: {
    'url:epi-forms/widget/templates/CustomMessageTextBox.html': "<div data-dojo-attach-point=\"customMessageContainer\" class=\"epi-forms-itemWidgetContainer\" style=\"display:none\">\n    <label class=\"epi-forms-cutom-error-message-label\">${res.custommessage.errormessagelabel}</label>\n    <input type=\"text\" data-dojo-attach-point=\"inputNode\" data-dojo-type=\"dijit/form/TextBox\" />\n    <a href=\"#\" data-dojo-attach-point=\"resetNode\" class=\"epi-previewableTextBox-link epi-functionLink\">${res.custommessage.resetbuttonlabel}</a>\n</div>"
  }
});

define("epi-forms/widget/CustomMessageTextBox", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/on", "dojo/dom-style", // dijit
"dijit/_TemplatedMixin", "dijit/_Widget", "dijit/form/TextBox", "dijit/_WidgetsInTemplateMixin", // epi-addons
"epi-forms/widget/_CustomValidationMessageMixin", // resources
"dojo/text!./templates/CustomMessageTextBox.html", "epi/i18n!epi/cms/nls/episerver.forms.validators"], function ( // dojo
declare, lang, on, domStyle, // dijit
_TemplatedMixin, _Widget, TextBox, _WidgetsInTemplateMixin, // epi-addons
_CustomValidationMessageMixin, // resources
template, res) {
  return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _CustomValidationMessageMixin], {
    res: res,
    templateString: template,
    currentValidatorType: null,
    _isReadonly: false,
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    postCreate: function postCreate() {
      this.inherited(arguments);
      this.own(on(this.inputNode, "change", lang.hitch(this, function () {
        var validatorMessage = this.inputNode.get("value");

        this._updateModelValidatorMessagesProperty(this.currentValidatorType, validatorMessage);

        this._updateResetButtonDisplayStatus();
      })), on(this.resetNode, "click", lang.hitch(this, function (event) {
        event.preventDefault();
        this.inputNode.set("value", this.defaultValidatorMessage);
        this.inputNode.focus();

        this._updateResetButtonDisplayStatus();
      })));
    },
    onChange: function onChange(newValue) {// summary:
      //      Callback when this widget's value is changed.
      // tags:
      //      callback
    },
    _setValueAttr: function _setValueAttr(val) {
      this.inputNode.set("value", val, false);

      this._updateResetButtonDisplayStatus(); // NOTE: to avoid onChange event fired after blur since this method will be called after postCreate


      this.inputNode._pendingOnChange = false;
      this.inputNode._lastValueReported = this.inputNode._resetValue = val;
    },
    _setReadonlyAttr: function _setReadonlyAttr(val) {
      this._isReadonly = val;

      if (val) {
        domStyle.set(this.resetNode, "display", "none");
        this.inputNode.set("disabled", "disabled");
      }
    },
    _getValueAttr: function _getValueAttr() {
      return this.inputNode.get("value");
    },
    _updateResetButtonDisplayStatus: function _updateResetButtonDisplayStatus() {
      // summary:
      //      Show the Reset button if the value of the textbox is different from the default message,
      //      otherwise hide it to indicate that we are using the default message.
      // tags:
      //      private
      var displayAttr = this._isReadonly || this.inputNode.get("value") === this.defaultValidatorMessage ? "none" : "";
      domStyle.set(this.resetNode, "display", displayAttr);
    }
  });
});